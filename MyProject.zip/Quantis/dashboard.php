<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: /Quantis/pages/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<body>
<h1>Dashboard</h1>
<p>Utilisateur connecté</p>
<a href="/Quantis/logout.php">Déconnexion</a>
</body>
</html>
